#include <iostream>
#include "animal.h"
using namespace std;
int main() {
    Animal animal1,animal2;
    int choose,anim;
    while(choose != -1){
        cout << "which animal 1 or 2: ";
        cin >> anim;
        cout << "choose what to do:\n "
                "1.Add Chromosome\n"
                "2.Make DNA from RNA\n"
                "3.Small Mutation one chromosome\n"
                "4.Big Mutation one chromosome\n"
                "5.Reverse Mutation one chromosome\n"
                "6.Check Dead Cells\n"
                "7.Big Mutation two chromosomes\n"
                "8.Find Palindormes\n"
                "9.Similarity of animals\n"
                "10.Equality of animals\n"
                "11.Asexual reproduction\n"
                "12.Sexual reproduction\n"
                "13.Enter Virus\n";
        cin >> choose;
        switch(choose){
            case 1:{
                Genome gen;
                Cell c1,c2;
                string RNA,DNA_1,DNA_2;
                DNAA dna;
                int count;
                cout << "how many chromosome: ";
                cin >> count;
                for(int i = 0;i < count;i++){
                    cout << "Enter RNA and DNA_1 and DNA_2: ";
                    cin >> RNA >> DNA_1 >> DNA_2;
                    dna.first = DNA_1;
                    dna.second = DNA_2;
                    gen.setter(RNA,dna);
                    if(anim == 1){
                        c1.addChromosome(gen);
                        animal1.set_cell(c1);
                    }
                    else if(anim == 2){
                        c2.addChromosome(gen);
                        animal2.set_cell(c2);
                    }
                }
                break;
            }
            case 2:{
                int num;
                cout << "which chromosome: ";
                cin >> num;
                if(anim == 1){
                    cout << animal1.Get_cell().get_chromosomes()[num - 1].getRNA()
                    << endl << animal1.Get_cell().get_chromosomes()[num - 1].createDNAfromRNA() << endl;
                }
                else if(anim == 2){
                    cout << animal2.Get_cell().get_chromosomes()[num - 1].getRNA()
                    << endl << animal2.Get_cell().get_chromosomes()[num - 1].createDNAfromRNA() << endl;
                }
                break;
            }
            case 3:{
                char first,second;
                int count,num;
                cout << "which chromosome: ";
                cin >> num;
                cout << "Enter first char and sec char and count: ";
                cin >> first >> second >> count;
                if(anim == 1){
                    animal1.Get_cell().smallJump(first,second,count,num);
                }
                else if(anim == 2){
                    animal2.Get_cell().smallJump(first,second,count,num);
                }
                break;
            }
            case 4:{
                string first,second;
                int num;
                cout << "which chromosome: ";
                cin >> num;
                cout << "Enter first str and sec str: ";
                cin >> first >> second;
                if(anim == 1){
                    animal1.Get_cell().get_chromosomes()[num - 1].bigJump(first,second);
                }
                else if(anim == 2){
                    animal2.Get_cell().get_chromosomes()[num - 1].bigJump(first,second);
                }
                break;
            }
            case 5:{
                string str;
                int num;
                cout << "which chromosome: ";
                cin >> num;
                cout << "Enter str: ";
                cin >> str;
                if(anim == 1){
                    animal1.Get_cell().get_chromosomes()[num - 1].reverseJump(str);
                }
                else if(anim == 2){
                    animal2.Get_cell().get_chromosomes()[num - 1].reverseJump(str);
                }
                break;
            }
            case 6:{
                if(anim == 1){
                    cout << "Cell befor death: " << animal1.Get_cell().get_chromosomes().size() << endl;
                    animal1.Get_cell().cellDeath();
                    cout << "Cell after death: " << animal1.Get_cell().get_chromosomes().size() << endl;
                }
                else if(anim == 2){
                    cout << "Cell befor death: " << animal2.Get_cell().get_chromosomes().size() << endl;
                    animal2.Get_cell().cellDeath();
                    cout << "Cell after death: " << animal2.Get_cell().get_chromosomes().size() << endl;
                }
                break;
            }
            case 7:{
                string first,second;
                int num1,num2;
                cout << "which chromosomes: ";
                cin >> num1 >> num2;
                cout << "Enter first str and sec str: ";
                cin >> first >> second;
                if(anim == 1){
                    animal1.Get_cell().bigJump(first,num1,second,num2);
                }
                else if(anim == 2){
                    animal2.Get_cell().bigJump(first,num1,second,num2);
                }
                break;
            }
            case 8:{
                int num;
                cout << "which chromosome: ";
                cin >> num;
                if(anim == 1){
                    animal1.Get_cell().findPalindromes(num);
                }
                else if(anim == 2){
                    animal2.Get_cell().findPalindromes(num);
                }
                break;
            }
            case 9:{
                cout << "Similarity: " << animal1.Similarity(animal2) << "%" << endl;
                break;
            }
            case 10:{
                if(animal1==animal2){
                    cout << "They are equal" << endl;
                }
                else{
                    cout << "They are not equal" << endl;
                }
                break;
            }
            case 11:{
                cout << "Asexual reproduction done!" << endl;
                cout << "Similarity of child: " << animal1.Tmgj().Similarity(animal1) << endl;
                break;
            }
            case 12:{
                cout << "Sexual reproduction done!" << endl;
                cout << "Similarity of child with f_animal: " << (animal1 + animal2).Similarity(animal1) << endl;
                cout << "Similarity of child with s_animal: " << (animal1 + animal2).Similarity(animal2) << endl;
                break;
            }
            case 13:{
                string RNA;
                bool temp;
                cout << "Enter virus RNA: ";
                cin >> RNA;
                Virus virus(RNA);
                if(anim == 1){
                    temp = virus.is_dangerous(animal1);
                }
                else{
                    temp = virus.is_dangerous(animal2);
                }
                if(temp){
                    cout << "virus is dangerous!" << endl;
                }
                else{
                    cout << "Virus is not dangerous" << endl;
                }
                break;
            }
        }
    }
}
